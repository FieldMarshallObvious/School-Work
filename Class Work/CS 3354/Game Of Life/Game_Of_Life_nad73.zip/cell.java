public class cell {
    public boolean isAlive;

    public cell( )
    {
        isAlive = false;
    }

    public cell ( boolean aliveCondition )
    {
        isAlive = aliveCondition;
    }
}