Complication instructions 

- lab2 should be compilied with the following command gcc lab2.c -o lab2 -std=c99 
- sort should be compilied with the following command gcc sort.c -o sort -std=c99
- pre should be compilied with the following command  gcc pre.c -o pre -std=c99

Permissions 
- Please give all the executables all permisions using chmod 777 <executable name>

