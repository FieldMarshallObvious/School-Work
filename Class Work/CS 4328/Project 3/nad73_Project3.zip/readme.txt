Complication instructions 

- gcc -pthread proj3A.c -std=c99
- gcc -pthread proj3B.c -std=99 
