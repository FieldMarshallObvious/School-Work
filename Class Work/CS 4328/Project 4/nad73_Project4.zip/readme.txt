Complication instructions 

- gcc -pthread proj4.c -std=c99

Other Notes
- The reference string is generated randomly. The reference string can be from 1 - 20 pages long, and each item in the reference string can between 1 - 5.