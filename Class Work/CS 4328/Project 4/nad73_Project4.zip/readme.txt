Complication instructions 

- gcc project4.c -std=c99

Other Notes
- The reference string is generated randomly. The reference string can be from 1 - 20 pages long, and each item in the reference string can between 1 - 5.